import 'package:flutter/material.dart';
import 'package:tp01/models/bachelor.dart';
import 'package:tp01/data/data_generator.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final List<Bachelor> bachelors = generateBachelors();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TP01 Finder',
      home: Scaffold(
        appBar: AppBar(
          title: const Text('TP01 Finder'),
        ),
        body: Center(
          child: ListView.builder(
            itemCount: bachelors.length,
            itemBuilder: (context, index) {
              final bachelor = bachelors[index];
              return Center(
                child: ListTile(
                  title: Text(
                      '${bachelor.gender.name}  :  ${bachelor.lastname} ${bachelor.firstname} '),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
